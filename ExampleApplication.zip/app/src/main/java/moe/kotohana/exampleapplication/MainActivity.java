package moe.kotohana.exampleapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ArrayList<Movie> arrayList = new ArrayList<>();
    CustomAdapter movieAdapter;
    ListView listView;
    final int REQUEST_CODE = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.listView);
        findViewById(R.id.launch).setOnClickListener(this);
        findViewById(R.id.cancel).setOnClickListener(this);
        init();
    }

    private void init() {

        Collections.addAll(arrayList,
                new Movie("트랜스포머: 최후의 기사",
                        "액션, 모험, SF",
                        "마이클 베이",
                        "마크 월버그, 안소니 홉킨스 외",
                        151,
                        R.drawable.movie1),
                new Movie("리얼",
                        "액션, 느와르",
                        "이사랑",
                        "김수현, 성동일, 이성민 외",
                        137,
                        R.drawable.movie2),
                new Movie("하루",
                        "스릴러",
                        "조선호",
                        "김명민, 변요한, 유재명 외",
                        90,
                        R.drawable.movice3)
        );
        movieAdapter = new CustomAdapter(this, arrayList);
        listView.setAdapter(movieAdapter);
    }


    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        getMenuInflater().inflate(R.menu.menu_tab, menu);

        return super.onCreatePanelMenu(featureId, menu);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.cancel:
                finish();
                break;
            case R.id.launch:
                startActivityForResult(new Intent(getApplicationContext(), MovieAddActivity.class), REQUEST_CODE);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == REQUEST_CODE && resultCode == RESULT_OK){
            arrayList.add((Movie) data.getSerializableExtra("movie"));
            movieAdapter.notifyDataSetChanged();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
