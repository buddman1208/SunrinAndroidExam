package moe.kotohana.exampleapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MovieAddActivity extends AppCompatActivity {

    EditText title, type, runningTime, director, actors;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_add);
        title = (EditText) findViewById(R.id.titleInput);
        type = (EditText) findViewById(R.id.typeInput);
        runningTime = (EditText) findViewById(R.id.runningTimeInput);
        director = (EditText) findViewById(R.id.directorInput);
        actors = (EditText) findViewById(R.id.actorsInput);
        intent = new Intent();
        findViewById(R.id.save).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isAllFilled(title, type, runningTime, director, actors)) {
                    Movie movie = new Movie(
                            title.getText().toString(), type.getText().toString(), director.getText().toString(), actors.getText().toString(),
                            Integer.parseInt(runningTime.getText().toString())
                    );
                    intent.putExtra("movie", movie);
                    setResult(RESULT_OK, intent);
                    finish();
                } else
                    Toast.makeText(MovieAddActivity.this, "빈칸을 모두 채워주세요", Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    boolean isAllFilled(EditText... editTexts) {
        for (EditText e : editTexts) {
            if (e.getText().toString().trim().equals("")) return false;
        }
        return true;
    }
}
