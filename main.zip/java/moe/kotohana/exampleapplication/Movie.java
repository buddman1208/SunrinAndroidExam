package moe.kotohana.exampleapplication;

import android.support.annotation.DrawableRes;
import android.support.annotation.IdRes;

import java.io.Serializable;

/**
 * Created by Junseok Oh on 2017-06-28.
 */

public class Movie implements Serializable{
    private String title, type, director, actors;
    private int runningTime;
    @DrawableRes
    private int drawable = 0;

    public Movie(String title, String type, String director, String actors, int runningTime) {
        this.title = title;
        this.type = type;
        this.director = director;
        this.actors = actors;
        this.runningTime = runningTime;
    }

    public Movie(String title, String type, String director, String actors, int runningTime, @DrawableRes int drawable) {
        this.title = title;
        this.type = type;
        this.director = director;
        this.actors = actors;
        this.runningTime = runningTime;
        this.drawable = drawable;
    }


    public int getDrawable() {
        return drawable;
    }

    public void setDrawable(int drawable) {
        this.drawable = drawable;
    }

    public String getTitle() {
        return title;
    }

    public String getType() {
        return type;
    }

    public String getDirector() {
        return director;
    }

    public String getActors() {
        return actors;
    }

    public String getRunningTime() {
        return (runningTime / 60) + "시간 " + (runningTime % 60) + " 분";
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public void setActors(String actors) {
        this.actors = actors;
    }

    public void setRunningTime(int runningTime) {
        this.runningTime = runningTime;
    }
}
